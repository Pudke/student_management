import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserGuard } from '../guards/authUser/user.guard';
import { ApplyLeaveComponent } from './components/apply-leave/apply-leave.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { MessageComponent } from './components/message/message.component';
import { MyMessagesComponent } from './components/my-messages/my-messages.component';
import { PayFeeComponent } from './components/pay-fee/pay-fee.component';
import { SendMessageComponent } from './components/send-message/send-message.component';
import { UpdateStudentComponent } from './components/update-student/update-student.component';
import { UserComponent } from './user.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent, canActivate: [UserGuard] },
  { path: 'student/:studentId', component: UpdateStudentComponent, canActivate: [UserGuard] },
  { path: 'fee/:studentId', component: PayFeeComponent, canActivate: [UserGuard] },
  { path: 'message', component: SendMessageComponent, canActivate: [UserGuard] },
  { path: 'sms/:teacherId', component: MessageComponent, canActivate: [UserGuard] },
  { path: 'inbox', component: MyMessagesComponent, canActivate: [UserGuard] },
  { path: 'leave', component: ApplyLeaveComponent, canActivate: [UserGuard] },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
