import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, of, tap } from 'rxjs';
import { UserStorageService } from 'src/app/services/storage/user-storage.service';
import { environment } from 'src/environments/environment';

const BASIC_URL = environment['BASIC_URL'];

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http: HttpClient,) { }

  getStudentByStudentId(studentId: any): Observable<any> {
    return this.http
      .get<[]>(`http://localhost:8081/api/student/${studentId}`, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Student Fetched successfully')),
        catchError(this.handleError<[]>('Error Getting Student', []))
      );
  }

  getStudentByUserId(): Observable<any> {
    return this.http
      .get<[]>(`http://localhost:8081/api/studentByUserId/${UserStorageService.getUserId()}`, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Student Fetched successfully')),
        catchError(this.handleError<[]>('Error Getting Student', []))
      );
  }

  updateStudent(serialNumber: any, studentDto: any): Observable<any> {
    return this.http
      .put<[]>(`http://localhost:8081/api/student/${serialNumber}`, studentDto, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Car Updated successfully')),
        catchError(this.handleError<[]>('Error updating Car', []))
      );
  }

  addFee(serialNumber: any, feeDto: any): Observable<any> {
    feeDto.userId = UserStorageService.getUserId();
    feeDto.serialNumber = serialNumber;
    return this.http
      .post<[]>(`http://localhost:8081/api/fee`, feeDto, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Fee paid successfully')),
        catchError(this.handleError<[]>('Error posting fee', []))
      );
  }

  messageToTeacher(teacherId: any, messageDto: any): Observable<any> {
    messageDto.userId = UserStorageService.getUserId();
    messageDto.teacherId = teacherId;
    return this.http
      .post<[]>(`http://localhost:8081/api/message`, messageDto, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Message sent successfully')),
        catchError(this.handleError<[]>('Error sending Message', []))
      );
  }

  getgetAllTeachersForHome(): Observable<any> {
    return this.http
      .get<[]>(`http://localhost:8082/api/teachersForHome`, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Teachers Fetched successfully')),
        catchError(this.handleError<[]>('Error Getting Teachers', []))
      );
  }

  getAlLMessagesByUserId(): Observable<any> {
    return this.http
      .get<[]>(`http://localhost:8081/api/messages/${UserStorageService.getUserId()}`, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Messages Fetched successfully')),
        catchError(this.handleError<[]>('Error Getting Messages', []))
      );
  }

  applyLeave(leaveDto: any): Observable<any> {
    leaveDto.userId = UserStorageService.getUserId();
    return this.http
      .post<[]>("http://localhost:8081/api/leave", leaveDto, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Leave applied successfully')),
        catchError(this.handleError<[]>('Error applying Leave', []))
      );
  }

  createAuthorizationHeader(): HttpHeaders {
    let authHeaders: HttpHeaders = new HttpHeaders();
    return authHeaders.set(
      'Authorization',
      'Bearer ' + UserStorageService.getToken()
    );
  }

  log(message: string): void {
    console.log(`User Auth Service: ${message}`);
  }

  handleError<T>(operation = 'operation', result?: T): any {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}

