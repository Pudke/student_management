import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { AdminService } from 'src/app/admin/admin-services/admin.service';
import { StudentService } from '../../user-services/student.service';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.scss']
})
export class MessageComponent implements OnInit {

  dateFormat = 'yyyy-MM-dd';
  isSpinning = false;
  size: NzButtonSize = 'large';
  validateForm!: FormGroup;
  teacherId: any = this.activatedroute.snapshot.params['teacherId'];


  constructor(private fb: FormBuilder,
    private studentService: StudentService,
    private notification: NzNotificationService,
    private router: Router,
    private activatedroute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      message: [null, [Validators.required]],
    });
  }

  messageToTeacher(teacherDto: any) {
    console.log(this.validateForm.value);
    console.log(teacherDto);
    this.isSpinning = true;
    this.studentService.messageToTeacher(this.teacherId, teacherDto).subscribe((res) => {
      console.log(res);
      this.isSpinning = false;
      if (res.status == "CREATED") {
        this.notification
          .success(
            'SUCCESS',
            `Message sent successfully!`,
            { nzDuration: 5000 }
          );
        this.router.navigateByUrl('user/dashboard');
      } else {
        this.notification
          .error(
            'ERROR',
            `${res.message}`,
            { nzDuration: 5000 }
          )
      }
    }, error => {
      console.log("errorr", error);
      if (error.status == 406) {
        this.notification
          .error(
            'ERROR',
            `${error.error}`,
            { nzDuration: 5000 }
          )
      }
      this.isSpinning = false;
    })
  }

}