import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { AdminService } from 'src/app/admin/admin-services/admin.service';
import { StudentService } from '../../user-services/student.service';

@Component({
  selector: 'app-my-messages',
  templateUrl: './my-messages.component.html',
  styleUrls: ['./my-messages.component.scss']
})
export class MyMessagesComponent implements OnInit {

  dateFormat = 'yyyy-MM-dd';
  isSpinning = false;
  size: NzButtonSize = 'large';
  validateForm!: FormGroup;
  messages: any
  gridStyle = {
    width: '25%',
    textAlign: 'center'
  };

  constructor(private fb: FormBuilder,
    private studentService: StudentService,
    private notification: NzNotificationService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
    });
    this.getAlLMessagesByUserId();
  }

  getAlLMessagesByUserId() {
    this.isSpinning = true;
    this.studentService.getAlLMessagesByUserId().subscribe((res) => {
      console.log(res);
      this.isSpinning = false;
      this.messages = res.data;
    })
  }
}
