import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { StudentService } from '../../user-services/student.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  dateFormat = 'yyyy-MM-dd';
  isSpinning = false;
  size: NzButtonSize = 'large';
  validateForm!: FormGroup;
  student: any

  constructor(private fb: FormBuilder,
    private studentService: StudentService,
    private notification: NzNotificationService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
    });
    this.getStudentByUserId();
  }

  getStudentByUserId() {
    this.isSpinning = true;
    this.studentService.getStudentByUserId().subscribe((res) => {
      console.log(res);
      this.isSpinning = false;
      this.student = res.data.studentDto;
    })
  }

}
