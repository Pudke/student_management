import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { AdminService } from '../../admin-services/admin.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  dateFormat = 'yyyy-MM-dd';
  isSpinning = false;
  size: NzButtonSize = 'large';
  validateForm!: FormGroup;
  students: any

  constructor(private fb: FormBuilder,
    private adminService: AdminService,
    private notification: NzNotificationService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      serialNumber: [null, [Validators.required]],
      name: [null, [Validators.required]],
      fatherName: [null, [Validators.required]],
      motherName: [null, [Validators.required]],
      studentClass: [null, [Validators.required]],
      dateOfBirth: [null, [Validators.required]],
      gender: [null, [Validators.required]],
    });
    this.getAllStudents();
  }

  getAllStudents() {
    this.isSpinning = true;
    this.adminService.getAllStudents().subscribe((res) => {
      console.log(res);
      this.isSpinning = false;
      this.students = res.data
    })
  }

}
