import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, of, tap } from 'rxjs';
import { UserStorageService } from 'src/app/services/storage/user-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient,) { }

  addStudent(studentDto: any): Observable<any> {
    studentDto.userId = UserStorageService.getUserId();
    return this.http
      .post<[]>("http://localhost:8081/api/student", studentDto, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Student posted successfully')),
        catchError(this.handleError<[]>('Error posting Student', []))
      );
  }

  getAllStudents(): Observable<any> {
    return this.http
      .get<[]>(`http://localhost:8081/api/students`, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Students Fetched successfully')),
        catchError(this.handleError<[]>('Error Getting Students', []))
      );
  }

  getStudentById(serialNumber): Observable<any> {
    return this.http
      .get<[]>(`http://localhost:8081/api/student/${serialNumber}`, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Student Fetched successfully')),
        catchError(this.handleError<[]>('Error Getting Student', []))
      );
  }

  updateStudent(serialNumber: any, studentDto: any): Observable<any> {
    return this.http
      .put<[]>(`http://localhost:8081/api/student/${serialNumber}`, studentDto, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Student Updated successfully')),
        catchError(this.handleError<[]>('Error updating Student', []))
      );
  }

  addTeacher(teacherDto: any): Observable<any> {
    return this.http
      .post<[]>(`http://localhost:8082/api/teacher`, teacherDto, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Teacher added successfully')),
        catchError(this.handleError<[]>('Error posting Teacher', []))
      );
  }

  getAllTeachers(): Observable<any> {
    return this.http
      .get<[]>("http://localhost:8082/api/teachers", {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Teachers fetched successfully')),
        catchError(this.handleError<[]>('Error getting Teachers', []))
      );
  }

  getTeacherById(teacherId: any): Observable<any> {
    return this.http
      .get<[]>(`http://localhost:8082/api/teacher/${teacherId}`, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Teacher fetched successfully')),
        catchError(this.handleError<[]>('Error getting Teacher', []))
      );
  }

  updateTeacher(teacherId: any, teacherDto: any): Observable<any> {
    return this.http
      .put<[]>(`http://localhost:8082/api/teacher/${teacherId}`, teacherDto, {
        headers: this.createAuthorizationHeader(),
      })
      .pipe(
        tap((_) => this.log('Teacher Updated successfully')),
        catchError(this.handleError<[]>('Error updating Teacher', []))
      );
  }

  createAuthorizationHeader(): HttpHeaders {
    let authHeaders: HttpHeaders = new HttpHeaders();
    return authHeaders.set(
      'Authorization',
      'Bearer ' + UserStorageService.getToken()
    );
  }

  log(message: string): void {
    console.log(`User Auth Service: ${message}`);
  }

  handleError<T>(operation = 'operation', result?: T): any {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
