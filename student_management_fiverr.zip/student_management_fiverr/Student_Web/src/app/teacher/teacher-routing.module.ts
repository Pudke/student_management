import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TeacherComponent } from './teacher.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { TeacherGuard } from '../guards/authTeacher/teacher.guard';

const routes: Routes = [{ path: '', component: TeacherComponent },
{ path: 'dashboard', component: DashboardComponent, canActivate: [TeacherGuard] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TeacherRoutingModule { }
