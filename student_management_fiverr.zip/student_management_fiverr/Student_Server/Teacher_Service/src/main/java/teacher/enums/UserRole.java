package teacher.enums;

public enum UserRole {
    ADMIN,
    STUDENT,
    TEACHER
}
