package teacher.services;

import teacher.dtos.UserDto;
import teacher.entities.User;
import teacher.enums.UserRole;
import teacher.response.GeneralResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import teacher.dtos.SingleTeacherDto;
import teacher.dtos.TeacherDto;
import teacher.repos.UserRepo;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private UserRepo userRepo;

    @Override
    public GeneralResponse addTeacher(TeacherDto teacherDto) {
        GeneralResponse response = new GeneralResponse();
        User user = new User();
        user.setName(teacherDto.getName());
        user.setEmail(teacherDto.getEmail());
        user.setPassword(new BCryptPasswordEncoder().encode(teacherDto.getPassword()));
        user.setRole(UserRole.TEACHER);
        userRepo.save(user);
        response.setMessage("Teacher added successfully!");
        response.setStatus(HttpStatus.CREATED);
        return response;
    }

    @Override
    public List<UserDto> getAllTeachers() {
        return userRepo.findAllByRole(UserRole.TEACHER).stream().map(User::getTeacherDto).collect(Collectors.toList());
    }

    @Override
    public List<UserDto> getAllTeachersForHome() {
        return userRepo.findAllByRole(UserRole.TEACHER).stream().map(User::getTeacherDto).collect(Collectors.toList());
    }

    @Override
    public SingleTeacherDto getTeacherById(Long teacherId) {
        SingleTeacherDto singleTeacherDto = new SingleTeacherDto();
        Optional<User> optionalUser = userRepo.findById(teacherId);
        if (optionalUser.isPresent()) {
            singleTeacherDto.setUserDto(optionalUser.get().getTeacherDto());
        }
        return singleTeacherDto;
    }

    @Override
    public GeneralResponse updateTeacher(Long teacherId, TeacherDto teacherDto) {
        GeneralResponse response = new GeneralResponse();
        Optional<User> optionalTeacher = userRepo.findById(teacherId);
        if (optionalTeacher.isPresent()) {
            User user = optionalTeacher.get();
            user.setName(teacherDto.getName());
            user.setEmail(teacherDto.getEmail());
            userRepo.save(user);
            response.setMessage("Teacher updated Successfully");
            response.setStatus(HttpStatus.OK);
        } else {
            response.setStatus(HttpStatus.NOT_ACCEPTABLE);
            response.setMessage("Teacher not found!");
        }
        return response;
    }

}




