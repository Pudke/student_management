package teacher.services;


import teacher.dtos.UserDto;
import teacher.response.GeneralResponse;
import teacher.dtos.SingleTeacherDto;
import teacher.dtos.TeacherDto;

import java.util.List;

public interface TeacherService {

    GeneralResponse addTeacher(TeacherDto teacherDto);

    List<UserDto> getAllTeachers();

    List<UserDto> getAllTeachersForHome();

    SingleTeacherDto getTeacherById(Long teacherId);

    GeneralResponse updateTeacher(Long teacherId, TeacherDto teacherDto);

}
