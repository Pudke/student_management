package teacher.entities;


import teacher.dtos.UserDto;
import teacher.enums.UserRole;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "users")
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String email;

    private String password;

    private String name;

    private String fatherName;

    private String motherName;

    private String studentClass;

    private Date dateOfBirth;

    private String gender;

    private UserRole role;

    public UserDto getTeacherDto() {
        UserDto userDto = new UserDto();
        userDto.setEmail(email);
        userDto.setName(name);
        userDto.setId(id);
        return userDto;
    }

}
