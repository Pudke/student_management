package teacher.dtos;

import lombok.Data;

@Data
public class SingleTeacherDto {

    private UserDto userDto;


}
