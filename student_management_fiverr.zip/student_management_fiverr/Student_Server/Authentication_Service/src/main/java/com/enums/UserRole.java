package com.enums;

public enum UserRole {
    ADMIN,
    STUDENT,
    TEACHER
}
