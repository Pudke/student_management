package com.dtos;

import lombok.Data;

import java.util.Date;

@Data
public class FeeDto {

    private Long id;

    private Long amount;

    private Date createdDate;

    private String month;

    private String year;

    private String givenBy;

    private String description;

    private Long userId;

}
