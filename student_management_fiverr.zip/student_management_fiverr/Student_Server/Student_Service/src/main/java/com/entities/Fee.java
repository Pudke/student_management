package com.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.dtos.FeeDto;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
public class Fee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long amount;

    private Date createdDate;

    private String month;

    private String year;

    private String givenBy;

    private String description;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private User user;

    public FeeDto getFeeDto() {
        FeeDto feeDto = new FeeDto();
        feeDto.setAmount(amount);
        feeDto.setCreatedDate(createdDate);
        feeDto.setMonth(month);
        feeDto.setGivenBy(givenBy);
        feeDto.setDescription(description);
        feeDto.setUserId(user.getId());
        return feeDto;
    }

}
