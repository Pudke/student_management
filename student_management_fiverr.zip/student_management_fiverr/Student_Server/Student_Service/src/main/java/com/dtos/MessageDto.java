package com.dtos;

import lombok.Data;

import java.util.Date;

@Data
public class MessageDto {

    private Long id;

    private String message;

    private Date date;

    private Long userId;

    private String username;

    private Long serialNumber;

    private Long teacherId;

    private String teacherName;

}

