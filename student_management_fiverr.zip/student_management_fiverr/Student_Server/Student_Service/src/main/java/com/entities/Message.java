package com.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.dtos.MessageDto;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String message;

    private Date date;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "teacher_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private User teacher;

    public MessageDto getMessageDto() {
        MessageDto messageDto = new MessageDto();
        messageDto.setId(id);
        messageDto.setMessage(message);
        messageDto.setDate(date);
        messageDto.setUserId(user.getId());
        messageDto.setUsername(user.getName());
        messageDto.setTeacherId(teacher.getId());
        messageDto.setTeacherName(teacher.getName());
        return messageDto;
    }
}
