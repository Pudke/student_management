package com.services;

import com.enums.UserRole;
import com.response.GeneralResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.dtos.*;
import com.entities.*;
import com.repos.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private FeeRepo feeRepo;

    @Autowired
    private MessageRepo messageRepo;

    @Autowired
    private LeaveRepo leaveRepo;

    @Override
    public GeneralResponse addStudent(StudentDto studentDto) {
        GeneralResponse response = new GeneralResponse();
        Optional<User> optionalUser = userRepo.findFirstByEmail(studentDto.getEmail());
        if (optionalUser.isEmpty()){
            User user = new User();
            user.setName(studentDto.getName());
            user.setRole(UserRole.STUDENT);
            user.setEmail(studentDto.getEmail());
            user.setPassword(new BCryptPasswordEncoder().encode(studentDto.getPassword()));
            user.setFatherName(studentDto.getFatherName());
            user.setMotherName(studentDto.getMotherName());
            user.setStudentClass(studentDto.getStudentClass());
            user.setDateOfBirth(studentDto.getDateOfBirth());
            user.setGender(studentDto.getGender());
            userRepo.save(user);
            response.setMessage("Student added successfully!");
            response.setStatus(HttpStatus.CREATED);
        } else {
            response.setStatus(HttpStatus.NOT_ACCEPTABLE);
            response.setMessage("Student already exist with this email!");
        }
        return response;
    }

    @Override
    public List<StudentDto> getAllStudents() {
        return userRepo.findAllByRole(UserRole.STUDENT).stream().map(User::getStudentDto).collect(Collectors.toList());
    }

    @Override
    public SingleStudentDto getStudentById(Long studentId) {
        SingleStudentDto singleStudentDto = new SingleStudentDto();
        Optional<User> optionalUser = userRepo.findById(studentId);
        if (optionalUser.isPresent()) {
            singleStudentDto.setStudentDto(optionalUser.get().getStudentDto());
        }
        return singleStudentDto;
    }

    @Override
    public GeneralResponse updateStudent(Long studentId, StudentDto studentDto) {
        GeneralResponse response = new GeneralResponse();
        Optional<User> optionalUser = userRepo.findById(studentId);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            user.setName(studentDto.getName());
            user.setRole(UserRole.STUDENT);
            user.setEmail(studentDto.getEmail());
            user.setFatherName(studentDto.getFatherName());
            user.setMotherName(studentDto.getMotherName());
            user.setStudentClass(studentDto.getStudentClass());
            user.setDateOfBirth(studentDto.getDateOfBirth());
            user.setGender(studentDto.getGender());
            userRepo.save(user);
            response.setMessage("Student updated Successfully");
            response.setStatus(HttpStatus.OK);
        } else {
            response.setStatus(HttpStatus.NOT_ACCEPTABLE);
            response.setMessage("Student not found!");
        }
        return response;
    }

    @Override
    public GeneralResponse addFee(FeeDto feeDto) {
        GeneralResponse response = new GeneralResponse();
        User user = null;
        Optional<User> userOptional = userRepo.findById(feeDto.getUserId());
        if (userOptional.isPresent()) {
            user = userOptional.get();
            Fee fee = new Fee();
            fee.setAmount(feeDto.getAmount());
            fee.setCreatedDate(new Date());
            fee.setMonth(feeDto.getMonth());
            fee.setYear(feeDto.getYear());
            fee.setGivenBy(feeDto.getGivenBy());
            fee.setDescription(feeDto.getDescription());
            fee.setUser(user);
            feeRepo.save(fee);
            response.setMessage("Fee added successfully!");
            response.setStatus(HttpStatus.CREATED);
        } else {
            response.setStatus(HttpStatus.NOT_ACCEPTABLE);
            response.setMessage("User or student not found!");
        }
        return response;
    }

    @Override
    public GeneralResponse messageToTeacher(MessageDto messageDto) {
        GeneralResponse response = new GeneralResponse();
        Optional<User> userOptional = userRepo.findById(messageDto.getUserId());
        Optional<User> optionalTeacher = userRepo.findById(messageDto.getTeacherId());
        if (userOptional.isPresent() && optionalTeacher.isPresent()) {
            Message message = new Message();
            message.setMessage(messageDto.getMessage());
            message.setUser(userOptional.get());
            message.setDate(new Date());
            message.setTeacher(optionalTeacher.get());
            messageRepo.save(message);
            response.setMessage("Message sent successfully!");
            response.setStatus(HttpStatus.CREATED);
        } else {
            response.setStatus(HttpStatus.NOT_ACCEPTABLE);
            response.setMessage("User or student not found!");
        }
        return response;
    }

    @Override
    public List<MessageDto> getAlLMessagesByUserId(Long userId) {
        return messageRepo.findAllByUserId(userId).stream().map(Message::getMessageDto).collect(Collectors.toList());
    }

    @Override
    public SingleStudentDto getStudentByUserId(Long userId) {
        SingleStudentDto singleStudentDto = new SingleStudentDto();
        Optional<User> optionalUser = userRepo.findById(userId);
        if (optionalUser.isPresent()) {
            singleStudentDto.setStudentDto(optionalUser.get().getStudentDto());
        }
        return singleStudentDto;
    }

    @Override
    public GeneralResponse applyLeave(StudentLeaveDto studentLeaveDto) {
        GeneralResponse response = new GeneralResponse();
        Optional<User> optionalUser = userRepo.findById(studentLeaveDto.getUserId());
        if (optionalUser.isPresent()) {
            StudentLeave studentLeave = new StudentLeave();
            studentLeave.setDate(new Date());
            studentLeave.setSubject(studentLeaveDto.getSubject());
            studentLeave.setBody(studentLeaveDto.getBody());
            studentLeave.setUser(optionalUser.get());
            leaveRepo.save(studentLeave);
            response.setMessage("Leave applied Successfully");
            response.setStatus(HttpStatus.CREATED);
        } else {
            response.setStatus(HttpStatus.NOT_ACCEPTABLE);
            response.setMessage("Student not found!");
        }
        return response;
    }

}




